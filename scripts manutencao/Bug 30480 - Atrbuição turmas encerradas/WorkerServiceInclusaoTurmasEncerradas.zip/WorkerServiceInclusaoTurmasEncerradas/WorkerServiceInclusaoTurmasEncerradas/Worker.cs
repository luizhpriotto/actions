using Dapper;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WorkerServiceInclusaoTurmasEncerradas
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;

        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {                
                Console.Write("Data partida (AAAA-MM-DD): ");
                var dataPartida = Console.ReadLine();

                var stringConexaoD1 = "User ID=user_se1426_cotic;Password=3ol_c0tic@;Data Source=10.49.16.136;Database=se1426;";

                using (SqlConnection connectionD1 = new SqlConnection(stringConexaoD1))
                {
                    var sqlQueryD1 = new StringBuilder();

                    sqlQueryD1.AppendLine("select distinct sc.cd_registro_funcional CodigoRf,");
                    sqlQueryD1.AppendLine("				   stg.cd_turma_escola CodigoTurma,");
                    sqlQueryD1.AppendLine("				   e.cd_escola CodigoUE,");
                    sqlQueryD1.AppendLine("				   max(aa.dt_disponibilizacao_aulas) DataFim");
                    sqlQueryD1.AppendLine("	from atribuicao_aula aa");
                    sqlQueryD1.AppendLine("		inner join v_cargo_base_cotic cbc");
                    sqlQueryD1.AppendLine("			on aa.cd_cargo_base_servidor = cbc.cd_cargo_base_servidor");
                    sqlQueryD1.AppendLine("		inner join v_servidor_cotic sc");
                    sqlQueryD1.AppendLine("			on cbc.cd_servidor = sc.cd_servidor");
                    sqlQueryD1.AppendLine("		inner join serie_turma_grade stg");
                    sqlQueryD1.AppendLine("			on aa.cd_serie_grade = stg.cd_serie_grade");
                    sqlQueryD1.AppendLine("		inner join turma_escola te");
                    sqlQueryD1.AppendLine("			on stg.cd_turma_escola = te.cd_turma_escola");
                    sqlQueryD1.AppendLine("		inner join escola e");
                    sqlQueryD1.AppendLine("			on te.cd_escola = e.cd_escola");
                    sqlQueryD1.AppendLine($"where aa.an_atribuicao = {dataPartida.Substring(0, 4)} and");
                    sqlQueryD1.AppendLine("       aa.dt_cancelamento is null and");
                    sqlQueryD1.AppendLine("       aa.dt_disponibilizacao_aulas is not null and");
                    sqlQueryD1.AppendLine($"      CONVERT(date, aa.dt_disponibilizacao_aulas) >= '{dataPartida}'");
                    sqlQueryD1.AppendLine("group by sc.cd_registro_funcional,");
                    sqlQueryD1.AppendLine("         stg.cd_turma_escola,");
                    sqlQueryD1.AppendLine("		    e.cd_escola,");
                    sqlQueryD1.AppendLine("		    te.dc_turma_escola");
                    sqlQueryD1.AppendLine("order by 1, 2, 3, 4");


                    var listaUsuarios = await connectionD1
                        .QueryAsync<DadosUsuarioTurmasHistoricasDto>(sqlQueryD1.ToString());

                    string stringConexaoSgp = "User ID=postgres;Password=Z7LfhyT0XqrpZSi3;Host=10.50.1.142;Port=5432;Database=sgp_db;Pooling=true;";

                    using (NpgsqlConnection connectionSGP = new NpgsqlConnection(stringConexaoSgp))
                    {
                        await connectionSGP.OpenAsync();
                        var transaction = connectionSGP.BeginTransaction();
                        var sqlQuerySgp = new StringBuilder();

                        sqlQuerySgp.AppendLine("delete from abrangencia a");
                        sqlQuerySgp.AppendLine("    using usuario u,");
                        sqlQuerySgp.AppendLine("          ue");
                        sqlQuerySgp.AppendLine("where u.login = @login and");                        
                        sqlQuerySgp.AppendLine("      ue.ue_id = @codigoUe and");
                        sqlQuerySgp.AppendLine("      a.usuario_id = u.id and");
                        sqlQuerySgp.AppendLine("      a.turma_id = @codigoTurma::int8 and");
                        sqlQuerySgp.AppendLine("      a.perfil = @perfil::uuid and");
                        sqlQuerySgp.AppendLine("      a.dt_fim_vinculo::date = @dataFim::date;");
                        sqlQuerySgp.AppendLine("insert into abrangencia (usuario_id, dre_id, ue_id, turma_id, perfil, historico, dt_fim_vinculo)");
                        sqlQuerySgp.AppendLine("select u.id, dre.dre_id::int8, ue.ue_id::int8, t.id, @perfil::uuid, true, @dataFim");
                        sqlQuerySgp.AppendLine("	from usuario u, ue, dre, turma t");
                        sqlQuerySgp.AppendLine("where u.login = @login and");
                        sqlQuerySgp.AppendLine("	  ue.ue_id = @codigoUe and");
                        sqlQuerySgp.AppendLine("	  ue.dre_id = dre.id and");
                        sqlQuerySgp.AppendLine("	  t.turma_id = @codigoTurma and");
                        sqlQuerySgp.AppendLine("	  not exists (select 1");
                        sqlQuerySgp.AppendLine("	 			  from abrangencia a2");
                        sqlQuerySgp.AppendLine("	 			  where a2.usuario_id = u.id and");
                        sqlQuerySgp.AppendLine("	 			        a2.dre_id = dre.dre_id::int8 and");
                        sqlQuerySgp.AppendLine("	 			        a2.ue_id = ue.ue_id::int8 and");
                        sqlQuerySgp.AppendLine("	 			        a2.turma_id = t.id and");
                        sqlQuerySgp.AppendLine("	 			        a2.perfil = @perfil::uuid and");
                        sqlQuerySgp.AppendLine("	 			        a2.historico and");
                        sqlQuerySgp.AppendLine("	 			        a2.dt_fim_vinculo::date = @dataFim::date)");
                        sqlQuerySgp.AppendLine("returning id;");

                        foreach (var item in listaUsuarios)
                        {
                            try
                            {
                                var id = await connectionSGP.ExecuteScalarAsync(sqlQuerySgp.ToString(), new
                                {
                                    codigoTurma = item.CodigoTurma,
                                    dataFim = item.DataFim,
                                    login = item.CodigoRf,
                                    codigoUe = item.CodigoUE,
                                    perfil = "40E1E074-37D6-E911-ABD6-F81654FE895D"
                                }, transaction);                                

                                _logger.LogInformation($"{(id == null ? "N�o " : string.Empty)}Processado - RF: {item.CodigoRf} - Turma: {item.CodigoTurma}");
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, $"Erro RF: {item.CodigoRf} - Turma: {item.CodigoTurma}");
                            }                            
                        }

                        transaction.Commit();
                    }                                        
                }

                await Task.Delay(1000, stoppingToken);
            }
        }
    }
}
