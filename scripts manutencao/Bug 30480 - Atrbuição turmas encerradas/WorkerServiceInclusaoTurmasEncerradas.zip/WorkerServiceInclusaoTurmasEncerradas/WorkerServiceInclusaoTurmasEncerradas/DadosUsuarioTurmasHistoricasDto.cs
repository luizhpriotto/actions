﻿using System;

namespace WorkerServiceInclusaoTurmasEncerradas
{
    public class DadosUsuarioTurmasHistoricasDto
    {
        public string CodigoRf { get; set; }
        public string CodigoTurma { get; set; }
        public string CodigoUE { get; set; }
        public DateTime DataFim { get; set; }
    }
}
